// Environment variables loader for Vercel
(function() {
    // Vercel injects environment variables prefixed with VITE_ into the window object
    // This script should be loaded before app.js
    
    // Set environment variables from Vercel's process.env (injected at build time)
    // For static sites, we need to read from a global config or meta tags
    
    // Method 1: Check if Vercel has injected variables
    if (typeof window.__VERCEL_ENV__ !== 'undefined') {
        console.log('Vercel environment detected');
    }
    
    // Method 2: Read from meta tags (we'll inject these)
    const metaUrl = document.querySelector('meta[name="supabase-url"]');
    const metaKey = document.querySelector('meta[name="supabase-anon-key"]');
    
    if (metaUrl && metaKey) {
        window.VITE_SUPABASE_URL = metaUrl.getAttribute('content');
        window.VITE_SUPABASE_ANON_KEY = metaKey.getAttribute('content');
        console.log('Environment variables loaded from meta tags');
    } else {
        console.log('Using default environment variables');
    }
})();